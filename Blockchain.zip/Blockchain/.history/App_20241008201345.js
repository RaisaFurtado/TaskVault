$(document).ready(function() {
    createTaskList();
});

// Auto focus on input of add task modal
$('#add-task-container').on('shown.bs.modal', function () {
    $('#new-task').trigger('focus');
});

async function createTaskList() {
    // Get account from the Ganache EVM
    try {
        await getAccount();
        // Set contract and set gas
        contract = new web3.eth.Contract(contractABI, contractAddress);
        try {
            const numberOfTask = await contract.methods.getTaskCount().call({ from: web3.eth.defaultAccount });
            console.log('Number of Tasks are ' + numberOfTask);
            // If there are tasks present
            if (numberOfTask != 0) {
                console.log('Start fetching tasks ...');
                for (let taskIterator = 0; taskIterator < numberOfTask; taskIterator++) {
                    try {
                        const task = await contract.methods.getTask(taskIterator).call({ from: web3.eth.defaultAccount });
                        if (task[0] != '') {
                            // addTaskToList add this task as children to the ul tag
                            addTaskToList(taskIterator, task[0], task[1]);
                        } else {
                            console.log('The index ' + taskIterator + ' is empty');
                        }
                    } catch (error) {
                        console.error('Failed to get Task ' + taskIterator, error);
                    }
                }
                // Update the task count in HTML
                updateTasksCount();
            }
        } catch (error) {
            console.error('Failed to get task count from blockchain', error);
        }
    } catch (error) {
        console.error('Failed to get the account', error);
    }
}

function addTaskToList(id, name, status) {
    console.log('addTaskToList(): Add Task ' + id + ' ' + [name, status]);
    let list = document.getElementById('list');
    let item = document.createElement('li');
    item.classList.add('list-group-item', 'border-0', 'd-flex', 'justify-content-between', 'align-items-center');
    item.id = 'item-' + id;
    let task = document.createTextNode(name);
    var checkbox = document.createElement("INPUT");
    checkbox.setAttribute("type", "checkbox");
    checkbox.setAttribute("id", "item-" + id + "-checkbox");
    checkbox.checked = status;

    if (status) {
        item.classList.add("task-done");
    }

    item.appendChild(task);
    item.appendChild(checkbox);
    list.appendChild(item);

    item.ondblclick = function () {
        removeTask(item.id);
    }

    checkbox.onclick = function () { changeTaskStatus(checkbox.id, id); };
}

async function removeTask(taskIndex) {
    console.log("removeTask(): Remove Task " + taskIndex);
    let taskSelector = '#' + taskIndex;
    taskIndex = taskIndex.replace('item-', '');
    try {
        await contract.methods.deleteTask(taskIndex).send({ from: web3.eth.defaultAccount });
        console.log('Remove Task ' + taskIndex + ' from the blockchain');
        $(taskSelector).remove();
        updateTasksCount();
    } catch (error) {
        console.error('Issue occurred while removing task item-' + taskIndex, error);
    }
}

async function changeTaskStatus(id, taskIndex) {
    let checkbox = document.getElementById(id);
    let textId = id.replace('-checkbox', '');
    let text = document.getElementById(textId);
    try {
        await contract.methods.updateStatus(taskIndex, checkbox.checked).send({ from: web3.eth.defaultAccount });
        console.log('changeTaskStatus(): Change status of task ' + textId + ' to ' + checkbox.checked);
        if (checkbox.checked) {
            text.classList.add("task-done");
        } else {
            text.classList.remove("task-done");
        }
    } catch (error) {
        console.error('Failed to change Status of task ' + textId + ' in blockchain', error);
    }
}

function updateTasksCount() {
    let list = document.getElementById('list');
    let taskCount = list.childElementCount;
    console.log('updateTaskCount(): The number of tasks are ' + taskCount);
    let count = document.getElementById('taskCount');
    count.innerText = taskCount + " Task" + (taskCount !== 1 ? "s" : ""); // Handle singular/plural
}

async function addTask() {
    // Get the input value
    let taskName = document.getElementById('new-task').value.trim();

    // Check if the input is valid and then add it
    if (taskName) {
        try {
            console.log('Adding task: ', taskName);
            await contract.methods.addTask(taskName).send({ from: web3.eth.defaultAccount });

            // After adding the task to the blockchain, fetch the updated task count
            const numberOfTask = await contract.methods.getTaskCount().call({ from: web3.eth.defaultAccount });
            // Add the task to the HTML
            addTaskToList(numberOfTask - 1, taskName, false); // Use numberOfTask - 1 for the new task ID

            // Clear the input field
            document.getElementById('new-task').value = '';
            // Update the task count in HTML
            updateTasksCount();
            console.log('Task added successfully');
        } catch (error) {
            console.error('Failed to add task to blockchain', error);
        }
    } else {
        console.log('Task name is empty');
    }
}
