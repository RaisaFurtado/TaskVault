$(document).ready(function () {
    createTaskList();  // Correctly invoke the function when the DOM is ready
});

// Auto focus on input of add task modal //
$('#add-task-container').on('shown.bs.modal', function () {
    $('#new-task').trigger('focus');
});

/**
* createTaskList() set the contract object and gets the number
* of tasks of the user and then calls addTaskToList() to add
* them to HTML one after the other, after all tasks are added
* then calls updateTaskCount()
* @author Gupta Shrinath
*/
async function createTaskList() {
    try {
        await getAccount();
        contract = new web3.eth.Contract(contractABI, contractAddress);

        let numberOfTask = await contract.methods.getTaskCount().call({ from: web3.eth.defaultAccount });
        console.log('Number of Tasks: ' + numberOfTask);

        if (numberOfTask > 0) {
            console.log('Fetching tasks...');
            for (let taskIterator = 0; taskIterator < numberOfTask; taskIterator++) {
                try {
                    let task = await contract.methods.getTask(taskIterator).call({ from: web3.eth.defaultAccount });
                    if (task[0]) {
                        addTaskToList(taskIterator, task[0], task[1]);  // Add task to HTML list
                    } else {
                        console.log('The index ' + taskIterator + ' is empty');
                    }
                } catch (error) {
                    console.log('Failed to get Task ' + taskIterator + ':', error);
                }
            }
            updateTasksCount();
        }
    } catch (error) {
        console.log('Failed to create task list:', error);
    }
}

/**
* addTaskToList() adds task details to the HTML list.
*/
function addTaskToList(id, name, status) {
    console.log('Add Task to List:', id, name, status);

    let list = document.getElementById('list');
    let item = document.createElement('li');
    item.classList.add('list-group-item', 'border-0', 'd-flex', 'justify-content-between', 'align-items-center');
    item.id = 'item-' + id;

    let task = document.createTextNode(name);
    let checkbox = document.createElement("INPUT");
    checkbox.setAttribute("type", "checkbox");
    checkbox.setAttribute("id", "item-" + id + "-checkbox");
    checkbox.checked = status;

    if (status) {
        item.classList.add("task-done");
    }

    list.appendChild(item);
    item.ondblclick = function () { removeTask(item.id); };

    item.appendChild(task);
    item.appendChild(checkbox);
    checkbox.onclick = function () { changeTaskStatus(checkbox.id, id); };
}

/**
* removeTask() removes a task from both blockchain and HTML.
*/
async function removeTask(taskIndex) {
    console.log("Remove Task:", taskIndex);

    let taskSelector = '#' + taskIndex;
    taskIndex = taskIndex.replace('item-', '');  // Extract task index

    try {
        await contract.methods.deleteTask(taskIndex).send({ from: web3.eth.defaultAccount });
        console.log('Task ' + taskIndex + ' removed from blockchain');
        $(taskSelector).remove();  // Remove from HTML
        updateTasksCount();
    } catch (error) {
        console.log('Failed to remove task:', error);
    }
}

/**
* changeTaskStatus() updates the task status in both blockchain and HTML.
*/
async function changeTaskStatus(id, taskIndex) {
    let checkbox = document.getElementById(id);
    let textId = id.replace('-checkbox', '');
    let text = document.getElementById(textId);

    try {
        await contract.methods.updateStatus(taskIndex, checkbox.checked).send({ from: web3.eth.defaultAccount });
        console.log('Updated task status for task ' + taskIndex + ' to ' + checkbox.checked);
       
        if (checkbox.checked) {
            text.classList.add("task-done");
        } else {
            text.classList.remove("task-done");
        }
    } catch (error) {
        console.log('Failed to update task status:', error);
    }
}

/**
* updateTasksCount() updates the task count displayed in HTML.
*/
function updateTasksCount() {
    let list = document.getElementById('list');
    let taskCount = list.childElementCount;
    console.log('Task count:', taskCount);
    document.getElementById('taskCount').innerText = taskCount + " Task(s)";
}

/**
* addTask() adds a new task to both blockchain and HTML.
*/
async function addTask(name) {
    let form = document.getElementById('add-task-form');
   
    if (form.checkValidity()) {
        console.log('Adding task:', name);

        document.getElementById('new-task').value = '';
        form.classList.remove('was-validated');

        try {
            let numberOfTask = await contract.methods.getTaskCount().call({ from: web3.eth.defaultAccount });
            addTaskToList(numberOfTask, name, false);
            updateTasksCount();

            await contract.methods.addTask(name).send({ from: web3.eth.defaultAccount });
            console.log('Task added to blockchain');
        } catch (error) {
            console.log('Failed to add task:', error);
        }

    } else {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            event.stopPropagation();
            form.classList.add('was-validated');
            document.getElementById('new-task').value = '';
        }, false);
    }
}

