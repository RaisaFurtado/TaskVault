$(document).ready(function () {
    console.log("DOM is ready, calling createTaskList...");
    createTaskList();  // Ensure this is properly called
});

/**
* createTaskList() set the contract object and gets the number
* of tasks of the user and then calls addTaskToList() to add
* them to HTML.
*/
async function createTaskList() {
    try {
        await getAccount();
        console.log("Account retrieved:", web3.eth.defaultAccount);

        contract = new web3.eth.Contract(contractABI, contractAddress);
        let numberOfTask = await contract.methods.getTaskCount().call({ from: web3.eth.defaultAccount });
        console.log('Number of Tasks:', numberOfTask);

        if (numberOfTask > 0) {
            for (let taskIterator = 0; taskIterator < numberOfTask; taskIterator++) {
                try {
                    let task = await contract.methods.getTask(taskIterator).call({ from: web3.eth.defaultAccount });
                    console.log(`Fetched Task ${taskIterator}:`, task);

                    if (task[0]) {
                        // Add task to HTML list
                        addTaskToList(taskIterator, task[0], task[1]);
                    } else {
                        console.log(`Task ${taskIterator} is empty`);
                    }
                } catch (error) {
                    console.log(`Error fetching Task ${taskIterator}:`, error);
                }
            }
            updateTasksCount();
        } else {
            console.log("No tasks found.");
        }
    } catch (error) {
        console.log('Error creating task list:', error);
    }
}

/**
* addTaskToList() adds task details to the HTML list.
*/
function addTaskToList(id, name, status) {
    console.log('Adding task to list:', id, name, status);

    let list = document.getElementById('list');
    if (!list) {
        console.error('Error: "list" element not found in HTML.');
        return;
    }

    let item = document.createElement('li');
    item.classList.add('list-group-item', 'border-0', 'd-flex', 'justify-content-between', 'align-items-center');
    item.id = 'item-' + id;

    let task = document.createTextNode(name);
    let checkbox = document.createElement("INPUT");
    checkbox.setAttribute("type", "checkbox");
    checkbox.setAttribute("id", "item-" + id + "-checkbox");
    checkbox.checked = status;

    if (status) {
        item.classList.add("task-done");
    }

    list.appendChild(item);
    item.ondblclick = function () { removeTask(item.id); };

    item.appendChild(task);
    item.appendChild(checkbox);
    checkbox.onclick = function () { changeTaskStatus(checkbox.id, id); };

    console.log('Task added to HTML successfully');
}

/**
* addTask() adds a new task to both blockchain and HTML.
*/
async function addTask() {
    let form = document.getElementById('add-task-form');
    let taskName = document.getElementById('new-task').value.trim();

    // Check form validity and task name
    if (form.checkValidity() && taskName) {
        console.log('Adding task to blockchain:', taskName);
        
        // Clear the input field and reset validation
        document.getElementById('new-task').value = '';
        form.classList.remove('was-validated');

        try {
            // Get the current task count
            let numberOfTask = await contract.methods.getTaskCount().call({ from: web3.eth.defaultAccount });
            console.log('Current task count:', numberOfTask);

            // Add task to HTML list and update task count
            addTaskToList(numberOfTask, taskName, false);
            updateTasksCount();

            // Add the task to the blockchain
            await contract.methods.addTask(taskName).send({ from: web3.eth.defaultAccount });
            console.log('Task added to blockchain');
        } catch (error) {
            console.error('Failed to add task to blockchain:', error);
        }
    } else {
        // If the form is invalid, prevent form submission and show validation
        form.classList.add('was-validated');
        console.log('Task name is invalid or empty.');
    }
}


/**
* updateTaskCount() updates the task count displayed in HTML.
*/
function updateTasksCount() {
    let list = document.getElementById('list');
    let taskCount = list ? list.childElementCount : 0;
    console.log('Task count:', taskCount);

    let count = document.getElementById('taskCount');
    if (count) {
        count.innerText = taskCount + " Task(s)";
    } else {
        console.error('Error: Task count element not found in HTML.');
    }
}

