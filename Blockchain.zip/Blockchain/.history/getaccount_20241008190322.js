// Check if web3 has already been injected by the browser (e.g., MetaMask)
// If not, fallback to Ganache local instance
if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);  // Use MetaMask's provider if available
} else {
    // Connect to Ganache
    web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:7545'));
}

// getAccount() will get the first account from Ganache and set it as defaultAccount for contract operations
async function getAccount() {
    try {
        let accounts = await web3.eth.getAccounts();
        if (accounts.length === 0) {
            console.log("No accounts found! Is your Ganache instance running?");
            return null;
        }
        web3.eth.defaultAccount = accounts[0];
        console.log(web3.eth.defaultAccount + ' account detected');
        return web3.eth.defaultAccount;
    } catch (error) {
        console.error("Error fetching accounts:", error);
        return null;
    }
}

// Call getAccount before performing any contract operation
getAccount().then((account) => {
    if (account) {
        // Perform contract operations here
        console.log("Ready to interact with the contract using account:", account);
    } else {
        console.log("Unable to detect an account.");
    }
});
